# Mecha Studio

## Files
- `addModule.html`: Mecha Studio editor.
- `database/mecha-studio.json`: JSON database file for GitHub.

## GitHub Pages
Publish the repository using GitHub Pages. The editor can be opened as a static page.

## Online database read/write
In the editor, open **Database GitHub** and enter:
- Repository: `owner/repo`
- Branch: `main` (or your branch)
- Path: `database/mecha-studio.json`
- A GitHub fine-grained Personal Access Token with **Contents: Read and write** access to this repository.

Use **Tải database từ GitHub** to load the online JSON and **Lưu database lên GitHub** to commit edits. The token is only held in the current page session and is not written to the JSON database or localStorage.

Keep a backup using **Tải database.json** before replacing online data. GitHub Pages itself is static; browser writes are made through the GitHub Contents API and require the token.
